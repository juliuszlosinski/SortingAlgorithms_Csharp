﻿using System;

namespace SortingAlgorithms
{
    static class SelectionSort<T> where T : IComparable
    {
        #region METHODS
        public static void Sort(T[] array)
        {
            int i = 0;
            int size = array.Length;
            while (i < size)
            {
                int minIndex = i;
                T minValue = array[i];
                int j = i;
                while (j < size)
                {
                    if (array[j].CompareTo(minValue) < 0)
                    {
                        minValue = array[j];
                        minIndex = j;
                    }
                    j++;
                }
                T tmp = array[i];
                array[i] = array[minIndex];
                array[minIndex] = tmp;
                i++;
            }
        }
        #endregion
    }
    static class InsertionSort<T> where T : IComparable
    {
        #region METHODS
        public static void Sort(T[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                int j = i;
                while (j != 0 && array[j - 1].CompareTo(array[j]) < 0)
                {
                    T tmp = array[j];
                    array[j] = array[j - 1];
                    array[j - 1] = tmp;
                    j--;
                }
            }
        }
        #endregion
    }
    static class BubbleSort<T> where T : IComparable
    {
        #region METHODS
        public static void Sort(T[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                for (int j = 1; j < array.Length; j++)
                {
                    if (array[j - 1].CompareTo(array[j]) > 0)
                    {
                        T tmp = array[j - 1];
                        array[j - 1] = array[j];
                        array[j] = tmp;
                    }
                }
            }
        }
        #endregion
    }
    static class QuickSort<T> where T : IComparable
    {
        #region METHODS
        public static void Sort(T[] array)
        {
            Sort(array, 0, array.Length - 1);
        }

        static void Sort(T[] array, int lower, int upper)
        {
            if (lower < upper)
            {
                int p = Partition(array, lower, upper);
                Sort(array, lower, p);
                Sort(array, p + 1, upper);
            }
        }

        static int Partition(T[] array, int lower, int upper)
        {
            int i = lower;
            int j = upper;
            T pivot = array[i];

            do
            {
                while (array[i].CompareTo(pivot) < 0)
                {
                    i++;
                }
                while (array[j].CompareTo(pivot) > 0)
                {
                    j--;
                }
                if (i >= j)
                {
                    break;
                }
                else
                {
                    T tmp = array[i];
                    array[i] = array[j];
                    array[j] = tmp;
                }

            } while (i <= j);

            return j;
        }
        #endregion
    }
    static class ShellSort<T> where T : IComparable
    {
        #region METHODS
        public static void Sort(T[] array)
        {
            int n = array.Length;
            int distance = n / 2;
            while (distance >= 1)
            {
                int j = distance;
                while (j < n)
                {
                    int i = j - distance;
                    while (i >= 0)
                    {
                        if (array[i + distance].CompareTo(array[i]) > 0)
                        {
                            break;
                        }
                        else
                        {
                            T tmp = array[i + distance];
                            array[i + distance] = array[i];
                            array[i] = tmp;
                            i -= distance;
                        }
                    }
                    j++;
                }
                distance /= 2;
            }
        }
        #endregion
    }
    static class MergeSort<T> where T : IComparable
    {
        #region METHODS
        public static void Sort(T[] array)
        {
            Sort(array, 0, array.Length - 1);
        }

        static void Sort(T[] array, int lower, int upper)
        {
            if (lower < upper)
            {
                int middle = (lower + upper) / 2;
                Sort(array, lower, middle);
                Sort(array, middle + 1, upper);
                Merge(array, lower, middle, upper);
            }
        }

        static void Merge(T[] array, int lower, int middle, int upper)
        {
            int i = lower;
            int j = middle + 1;

            T[] tmp = new T[array.Length];
            int k = lower;

            while (i <= middle && j <= upper)
            {
                if (array[i].CompareTo(array[j]) < 0)
                {
                    tmp[k] = array[i];
                    i++;
                }
                else
                {
                    tmp[k] = array[j];
                    j++;
                }
                k++;
            }

            if (i > middle)
            {
                while (j <= upper)
                {
                    tmp[k] = array[j];
                    j++;
                    k++;
                }
            }
            else
            {
                while (i <= middle)
                {
                    tmp[k] = array[i];
                    i++;
                    k++;
                }
            }

            for (int x = lower; x <= upper; x++)
            {
                array[x] = tmp[x];
            }
        }
        #endregion
    }
    static class GnomeSort<T> where T : IComparable
    {
        #region METHODS
        public static void Sort(T[] array)
        {
            int n = array.Length;
            int i = 0;
            while (i < n)
            {
                if (i == 0)
                {
                    i++;
                }
                else if (array[i - 1].CompareTo(array[i]) > 0)
                {
                    T tmp = array[i - 1];
                    array[i - 1] = array[i];
                    array[i] = tmp;
                    i--;
                }
                else
                {
                    i++;
                }
            }
        }
        #endregion
    }
}

static class Input
{
    public static void Main(string[] args)
    {

    }
}
